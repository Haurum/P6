CREATE FUNCTION st_quantile (rast raster, exclude_nodata_value boolean, quantile double precision DEFAULT NULL::double precision) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT (_st_quantile($1, 1, $2, 1, ARRAY[$3]::double precision[])).value 
$$
