CREATE FUNCTION _st_samealignment_finalfn (agg agg_samealignment) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT $1.aligned 
$$
