CREATE FUNCTION st_dwithin (rast1 raster, rast2 raster, distance double precision) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT st_dwithin($1, NULL::integer, $2, NULL::integer, $3) 
$$
