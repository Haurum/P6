CREATE FUNCTION st_summarystats (rastertable text, rastercolumn text, exclude_nodata_value boolean, OUT count bigint, OUT sum double precision, OUT mean double precision, OUT stddev double precision, OUT min double precision, OUT max double precision) RETURNS record
	LANGUAGE sql
AS $$
 SELECT _st_summarystats($1, $2, 1, $3, 1) 
$$
