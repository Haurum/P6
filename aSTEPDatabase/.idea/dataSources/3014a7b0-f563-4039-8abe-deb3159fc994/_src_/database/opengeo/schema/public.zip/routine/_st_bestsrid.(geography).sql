CREATE FUNCTION _st_bestsrid (geography) RETURNS integer
	LANGUAGE sql
AS $$
SELECT _ST_BestSRID($1,$1)
$$
