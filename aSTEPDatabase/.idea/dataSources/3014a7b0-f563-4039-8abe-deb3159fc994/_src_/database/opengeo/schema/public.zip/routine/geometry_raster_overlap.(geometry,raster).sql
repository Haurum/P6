CREATE FUNCTION geometry_raster_overlap (geometry, raster) RETURNS boolean
	LANGUAGE sql
AS $$
select $1 && $2::geometry
$$
