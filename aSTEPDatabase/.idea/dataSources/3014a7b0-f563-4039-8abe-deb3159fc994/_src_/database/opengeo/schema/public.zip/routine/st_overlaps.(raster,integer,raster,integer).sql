CREATE FUNCTION st_overlaps (rast1 raster, nband1 integer, rast2 raster, nband2 integer) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT $1 && $3 AND CASE WHEN $2 IS NULL OR $4 IS NULL THEN _st_overlaps(st_convexhull($1), st_convexhull($3)) ELSE _st_overlaps($1, $2, $3, $4) END 
$$
