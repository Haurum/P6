CREATE FUNCTION st_geomfromwkb (bytea, integer) RETURNS geometry
	LANGUAGE sql
AS $$
SELECT ST_SetSRID(ST_GeomFromWKB($1), $2)
$$
