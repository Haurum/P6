CREATE FUNCTION st_worldtorastercoordy (rast raster, xw double precision, yw double precision) RETURNS integer
	LANGUAGE sql
AS $$
 SELECT rowy FROM _st_worldtorastercoord($1, $2, $3) 
$$
