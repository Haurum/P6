CREATE FUNCTION st_polygon (geometry, integer) RETURNS geometry
	LANGUAGE sql
AS $$
 
	SELECT ST_SetSRID(ST_MakePolygon($1), $2)
	
$$
