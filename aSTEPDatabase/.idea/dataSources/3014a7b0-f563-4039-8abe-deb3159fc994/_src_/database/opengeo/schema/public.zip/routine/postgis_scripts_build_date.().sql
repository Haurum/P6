CREATE FUNCTION postgis_scripts_build_date () RETURNS text
	LANGUAGE sql
AS $$
SELECT '2015-12-10 11:19:51'::text AS version
$$
