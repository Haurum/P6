CREATE FUNCTION st_multipolygonfromtext (text) RETURNS geometry
	LANGUAGE sql
AS $$
SELECT ST_MPolyFromText($1)
$$
