CREATE FUNCTION st_pixelaspoint (rast raster, x integer, y integer) RETURNS geometry
	LANGUAGE sql
AS $$
 SELECT ST_PointN(ST_ExteriorRing(geom), 1) FROM _st_pixelaspolygons($1, NULL, $2, $3) 
$$
