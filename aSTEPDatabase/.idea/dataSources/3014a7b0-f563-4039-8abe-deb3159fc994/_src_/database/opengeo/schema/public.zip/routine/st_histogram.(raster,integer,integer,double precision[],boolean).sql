CREATE FUNCTION st_histogram (rast raster, nband integer, bins integer, width double precision[] DEFAULT NULL::double precision[], "right" boolean DEFAULT false, OUT min double precision, OUT max double precision, OUT count bigint, OUT percent double precision) RETURNS SETOF record
	LANGUAGE sql
AS $$
 SELECT min, max, count, percent FROM _st_histogram($1, $2, TRUE, 1, $3, $4, $5) 
$$
