CREATE FUNCTION st_resample (rast raster, ref raster, usescale boolean, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125) RETURNS raster
	LANGUAGE sql
AS $$
 SELECT st_resample($1, $2, $4, $5, $3) 
$$
