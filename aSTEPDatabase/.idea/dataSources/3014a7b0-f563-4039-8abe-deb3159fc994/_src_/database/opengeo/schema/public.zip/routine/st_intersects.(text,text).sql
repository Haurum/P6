CREATE FUNCTION st_intersects (text, text) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT ST_Intersects($1::geometry, $2::geometry);  
$$
