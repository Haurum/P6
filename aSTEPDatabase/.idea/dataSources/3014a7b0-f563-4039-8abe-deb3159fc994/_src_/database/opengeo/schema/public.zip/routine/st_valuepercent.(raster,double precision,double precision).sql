CREATE FUNCTION st_valuepercent (rast raster, searchvalue double precision, roundto double precision DEFAULT 0) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT (_st_valuecount($1, 1, TRUE, ARRAY[$2]::double precision[], $3)).percent 
$$
