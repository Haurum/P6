CREATE FUNCTION st_contains (geom1 geometry, geom2 geometry) RETURNS boolean
	LANGUAGE sql
AS $$
SELECT $1 && $2 AND _ST_Contains($1,$2)
$$
