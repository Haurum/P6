CREATE FUNCTION st_asgml (geom geometry, maxdecimaldigits integer DEFAULT 15, options integer DEFAULT 0) RETURNS text
	LANGUAGE sql
AS $$
 SELECT _ST_AsGML(2, $1, $2, $3, null, null); 
$$
