CREATE FUNCTION st_approxcount (rast raster, sample_percent double precision) RETURNS bigint
	LANGUAGE sql
AS $$
 SELECT _st_count($1, 1, TRUE, $2) 
$$
