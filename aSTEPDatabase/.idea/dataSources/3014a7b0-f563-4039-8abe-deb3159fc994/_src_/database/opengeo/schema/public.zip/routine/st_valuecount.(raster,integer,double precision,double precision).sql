CREATE FUNCTION st_valuecount (rast raster, nband integer, searchvalue double precision, roundto double precision DEFAULT 0) RETURNS integer
	LANGUAGE sql
AS $$
 SELECT (_st_valuecount($1, $2, TRUE, ARRAY[$3]::double precision[], $4)).count 
$$
