CREATE FUNCTION st_setbandnodatavalue (rast raster, nodatavalue double precision) RETURNS raster
	LANGUAGE sql
AS $$
 SELECT st_setbandnodatavalue($1, 1, $2, FALSE) 
$$
