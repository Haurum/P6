CREATE FUNCTION box3dtobox (box3d) RETURNS box
	LANGUAGE sql
AS $$
SELECT box($1)
$$
