CREATE FUNCTION postgis_scripts_installed () RETURNS text
	LANGUAGE sql
AS $$
 SELECT '2.1.7'::text || ' r' || 13414::text AS version 
$$
