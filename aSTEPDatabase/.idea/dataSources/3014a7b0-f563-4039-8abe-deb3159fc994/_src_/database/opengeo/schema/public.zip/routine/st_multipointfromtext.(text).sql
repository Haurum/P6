CREATE FUNCTION st_multipointfromtext (text) RETURNS geometry
	LANGUAGE sql
AS $$
SELECT ST_MPointFromText($1)
$$
